<?php echo '<div align="right">
		<a href="test.html">&emsp;&emsp; HOME <i class="fa fa-angle-down" style="font-size:15px"></i>&emsp; &emsp;</a>
		<a href="h_page.html"> PLANNER <i class="fa fa-angle-down" style="font-size:15px"></i>&emsp; &emsp;</a>
		<a href="h_page.html"> LOGIN <i class="fa fa-angle-down" style="font-size:15px"></i> &emsp; &emsp;</a>
		<a href="h_page.html"> DESTINATIONS <i class="fa fa-angle-down" style="font-size:15px"></i> &emsp;&emsp;</a>
		<a href="h_page.html"> ABOUT <i class="fa fa-angle-down" style="font-size:15px"></i> &emsp;&emsp; </a>
		<hr style="border: 0.25px solid#DACEC8;" /><br> <br>
		<a href="map_page.html"><i class="material-icons" style="font-size:60px;position: absolute;left: 1200px;top: 525px;">public &emsp; &emsp;</i></a>
		</div>'; ?>